import re, sys
def is_it_palindrome(word:str)-> bool:
    try:
        clean = re.sub(r'[^a-zA-Z0-9\s]', '', word).replace(" ", "").lower()
    except Exception as e:
        print(f"something happened: {e}")
        sys.exit()
    if not isinstance(word,str):
        raise TypeError("thou input is not a string")
    return clean == clean[::-1]

    
    
if __name__ == "__main__":
   print(is_it_palindrome("Racecar"))
   print(is_it_palindrome("baggy jeans"))
   print(is_it_palindrome("taco cat"))
   print(is_it_palindrome("A man, a Plan, a canal: Panama"))
    


        
        